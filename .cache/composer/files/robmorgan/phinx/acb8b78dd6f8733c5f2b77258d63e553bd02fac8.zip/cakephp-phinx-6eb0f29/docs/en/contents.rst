Contents
########

.. toctree::
   :caption: Phinx

   intro
   goals
   install
   migrations
   seeding
   commands
   configuration
   copyright
